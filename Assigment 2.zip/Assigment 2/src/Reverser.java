
public class Reverser extends Transpose {
	
	public Reverser(String s) {
		
		// complete constructor
		super(s);
	}
	
	public String reverseText(String word) {
		
		//complete this method so that it reverses the original string
		String reversed = "";
		for(int i = word.length()-1;i>=0; i--) {
			
			reversed += word.charAt(i);
		}
		return reversed;
	}
	
	public String decode(String word) {
		
		//complete this method so that it reverses the reversed String
		return reverseText(word);
	}
}
