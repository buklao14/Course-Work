/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhashing;

/**
 *
 * @author Rodolfo
 */
public class Customer {
    String name, address, phone;
    
    Customer(String name, String address, String phone){
        this.name = name;
        this.address = address;
        this.phone = phone;
    }
    @Override
        public String toString(){
            return "Name: " + name + "\nAddress: " + address + "\nPhone: " + phone;
        }
}
