/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhashing;

/**
 *
 * @author Rodolfo
 */
public class CustomerHashing{
    // hashTable used to store array of chains //
    private CustomerNode[] hashTable;
    
    CustomerHashing(){
        hashTable = new CustomerNode[10000];
    }
    
    private int hashCode(String key){
        int keyLength = key.length();
        String keyString = key.substring(keyLength - 4);
        return Integer.parseInt(keyString);
    }
    
    // remove a given key and its information //
    public Customer remove(String key){
        int cellIndex = hashCode(key);
        
        CustomerNode head = hashTable[cellIndex];
        
        CustomerNode prev = null;
        while(head != null){
            if(head.cust.phone.equals(key)){
                break;
            }
            else{
                prev = head;
                head = head.next; 
            }
        }
            if(head == null){
                return null;
            }
            
            if(prev != null){
                prev.next = head.next;
            }
            else{
                hashTable[cellIndex] = head.next;
            }
        return head.cust;
    }
    
    public Customer get(String key){
        int bucketIndex = hashCode(key);
        CustomerNode head = hashTable[bucketIndex];
        
        while(head != null){
            if(head.cust.phone.equals(key)){
                return head.cust;
            }
            head = head.next;
        }
        return null;
    }
    
    public void add(String key, Customer value){
        int bucketIndex = hashCode(key);
        CustomerNode head = hashTable[bucketIndex];
        
        while(head != null){
            if(head.cust.phone.equals(key)){
                head.cust = value;
                return;
            }
            head = head.next;
        }
        
        head = hashTable[bucketIndex];
        CustomerNode newNode = new CustomerNode(value);
        newNode.next = head;
        hashTable[bucketIndex] = newNode;
    }
}