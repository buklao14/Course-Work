/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhashing;

/**
 *
 * @author Rodolfo
 */
public class TestHashing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       CustomerHashing map = new CustomerHashing();
       String phone1 = "305-445-3813";
       Customer customer1 = new Customer("Armando Rojas", "SW 12th ST", phone1);
       
       String phone2 = "786-773-4041";
       Customer customer2 = new Customer("Jose Fernandez", "1250 S Miami avenue", phone2);
       
       String phone3 = "305-886-4142";
       Customer customer3 = new Customer("Irvin Gallardo", "SW 8th ST", phone3);
       
       String phone4 = "305-264-9636";
       Customer customer4 = new Customer("Juan Guerra", "500 Byscaine blvd", phone4);
       
       System.out.println("Adding values in map...");
       System.out.println("\nAdding: \n"+ customer1);
       map.add(phone1, customer1);
       
       System.out.println("\nAdding: \n"+ customer2);
       map.add(phone2, customer2);
       
       System.out.println("\nAdding: \n"+ customer3);
       map.add(phone3, customer3);
       
       System.out.println("\nAdding: \n"+ customer4);
       map.add(phone4, customer4);
       
       System.out.println("\nGetting values of " + phone2 + " from map.");
       Customer customer = map.get(phone2);
       System.out.println(customer);
       
       System.out.println("\nRemoving "+ phone4);
       map.remove(phone4);
    }
}
