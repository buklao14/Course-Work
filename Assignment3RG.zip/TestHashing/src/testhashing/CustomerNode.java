/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testhashing;

/**
 *
 * @author Rodolfo
 */
public class CustomerNode {
    Customer cust;
    CustomerNode next;
    
    CustomerNode(Customer cust){
        this.cust = cust;
        next = null;
    }
}
