import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;

public class MyPreprocessor {

	public static void main(String[] args) throws IOException{
		
		FileReader fr = new FileReader("text.txt");
		
		BufferedReader br = new BufferedReader(fr);
		
		Preprocessor p = new Preprocessor();
		
		String preLine;
		
		while((preLine=br.readLine()) != null) {
			
			System.out.println("Line is:" + preLine + " is Balanced?" + p.balance_Check(preLine));
		}

	}

}
