import java.util.Stack;
import java.util.EmptyStackException;

class Preprocessor {
	
	public static boolean balance_Check(String check) {
		
		Stack<Character>st = new Stack<Character>();
		
		for(int i=0; i<check.length(); i++) {
			
			char c = check.charAt(i);
			
			if(c == '[' || c == '{' || c == '(' || c == '/') {
				
				switch(c) {
				
				case '[':
					st.push(c);
					break;
				
				case '{':
					st.push(c);
					break;
					
				case '(':
					st.push(c);
					break;
					
				case '/':
					char t = check.charAt(i+1);
					if(t=='*')
					st.push(c);
					break;
					
				default:
					break;
				}
			}
			
			else if(c==']' || c == '}' || c == ')' || c == '*') {
				
				if(st.empty())
					return false;
				
				switch(c) {
				
				case ']':
					if(st.pop() != '[')
						return false;
						break;
				
				case '}':
					if(st.pop() != '{')
						return false;
						break;
				
				case ')':
					if(st.pop() != '(')
						return false;
						break;
				
				case '*':
					if(check.charAt(i+1) == '/')
						if(st.pop() != '/')
							return false;
							break;
				default:
					break;
				}
			}
		}
		
		if(st.empty())
			return true;
		return false;
	}
}
