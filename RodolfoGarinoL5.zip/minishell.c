// I Affirm that i wrote this program myself without any help from any other people or sources from the internet. //

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(){
	pid_t pid1, pid2;
	int status;
	int pipefds[2];
	int ret;

	// creating pipe for the child process
	ret = pipe(pipefds);

	// checking if there is an error while creating the pipe
	if(ret < 0){
		perror("error creating pipe.\n");
		return -1;
	}

	// creating child[1] and looking for error while forking
	if((pid1 = fork()) < 0){
		perror("error forking child[1].\n");
		return -1;
	}

	// execute ls -al for child[1] and closing read end of the pipe
	if(pid1 == 0){
		char *args[] = {"/bin/ls", "-al", NULL};
		close(1);
		dup2(pipefds[1], 1);
		close(pipefds[0]);
		execvp(args[0], args);
	}

	// creating child[2] and looking for error while forking
	if((pid2 = fork()) < 0){
		perror("error forking child[2].\n");
		return -1;	
	}

	// execute 'grep minishell.c' for child[2] and close write end of pipe
	if(pid2 == 0){
		char *args[] = {"/bin/grep", "minishell.c", NULL};
		close(0);
		dup2(pipefds[0], 0);
		close(pipefds[1]);
		execvp(args[0], args);
	}
	wait(&status);
	fflush(stdout);

	// printing the PID of child[1] and child[2] 
	if(pid2 > 0 && pid1 > 0){
		printf("PID of child[1]: %d\n", pid1);
		printf("PID of child[2]: %d\n", pid2);
	}

	// closing both pipes in the parent
	close(pipefds[0]);
	close(pipefds[1]);
	return 0;
}

