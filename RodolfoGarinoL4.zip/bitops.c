// I Affirm that i wrote this program myself without any help from any other people or sources from the internet. //

#include <stdio.h>
#include <ctype.h>

int main(){

unsigned input;
unsigned output;

char option;
char answer;
int bits;

do{
 do{
	// Asking user for desired value and storing it in input //
	printf("Enter a Value between 1 and 1000.\n");
	scanf("%u", &input);
  } 
    while(input < 1 || input > 1000);
	getchar();
	do{
		// Asking user if they wish to Set or Clear a desired amount of bits, storing in option //
		printf("Do you wish to set (s) or clear (c)?\n");
		scanf("%c", &option);
		option = tolower(option);
  }
    // As long as option is not equal to char S and C, perform action below //
    while(option != 's' && option != 'c');
	do{
		// asking user which bit they want to set/clear between 0-31, storing in bits //
		printf("which bit (0-31) do you want to set or clear?\n");
		scanf("%d", &bits);
  }
    while(bits < 0 || bits > 31);
	// if option is Set output = input or left shift amount of bits //
	if(option == 's'){
		output = input | (0x1 << bits);
  }
	else{
		// else the option is Clear output = input and we use the NOT operand //
		output = input & (~(0x1 << bits));
  }
	printf("input: %u\n", input);
	printf("output: %u\n", output);
	printf("Do you wish to continue y/n?\n");
	getchar();
	scanf("%c", &answer);
 }
   // as long as the answer is Yes, run the program again //
    while(answer == 'y' || answer == 'Y');	
}
