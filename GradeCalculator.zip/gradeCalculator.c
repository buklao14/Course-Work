// I Affirm that i wrote this program myself without any help from any other people or sources from the internet. //
#include <stdio.h>

int main(){
// Printing out my name, last name and student ID //
	printf("Student Name: Rodolfo Garino");
	printf("\n");
	printf("Panther ID: 6227112");
	printf("\n");

// creating an array of characters for all courses //
char courses[6][8] = {
	"COP2210",
	"ENC1101",
	"CGS3095",
	"CEN4010",
	"COP3530",
	"COP4338"
 };

// creating an array of integers for all courses credits //
int credits[6] = {
	3,
	3,
	3,
	4,
	3,
	3
 };

// creating a floating array in order to hold decimal numbers for grades //
float grades[6] = {
	4.00,
	2.67,
	3.00,
	4.50,
	5.00,
	2.75
 };

// initializing i , totalCredits and totalGrades and Pointsfor later use //
int i = 0;
int totalCredits = 0;
float totalGradePoints = 0;

// Printing the titles for the box of contents //
printf("%s\n","| Courses | Credits | Grades | Grade Points Earned |");

// creating for loop to add values to total Credits and Grades //
for (i; i<6; i++){
	totalCredits = totalCredits + credits[i];
	totalGradePoints = totalGradePoints + (credits[i] * grades[i]);
	printf(courses[i]);
	printf("\t\t");
	printf("%d\t", credits[i]);
	printf("%.2f", grades[i]);
	printf("\t\t     ");
	printf("%.2f", (credits[i] * grades[i]));
	printf("\n");
 };

// Printing Total credits and grade points earned as well as current GPA //
printf("Total");
printf("\t\t");
printf("%d\t", totalCredits);
printf("\t\t     ");
printf("%2.2f", totalGradePoints);
printf("\t\t");
printf("\n");
printf("Current GPA:   ");
printf("%.2f\n", (totalGradePoints / totalCredits));
return 0;
};
