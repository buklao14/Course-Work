// I Affirm that i wrote this program myself without any help from any other people or sources from the internet. //
#include <stdio.h>
#include <string.h>
#include <unistd.h>

// Declaring Constants //
#define n 10000
#define OUT 0
#define IN 1

// Creating method countWords //
unsigned countWords(char *str){
	int state = OUT;
	unsigned wc = 0;
while(*str){
	if(*str == ' ' || *str == '\n' || *str == '\t'){
			state = OUT;
	}
	else if(state == OUT){
		state = IN;
		wc++;
	}
	str++;
 }
return wc;
}

// Creating method for all words //
void all_words(char *str1, int num_words){
	int i, j, c = 0;
	char temp[50], *split_str, str[60][20];
	split_str = strtok(str1, " ,.-");
// Using while loop to read until a NULL //
while(split_str != NULL){
	strcpy(str[c], split_str);
	split_str = strtok(NULL, " ,.-");
	c++;
 }
for(i=1; i<num_words; i++){
	for(j=1; j<=num_words - i; j++){
		if(strcmp(str[j-1], str[j])>0){
			strcpy(temp, str[j-1]);
			strcpy(str[j-1], str[j]);
			strcpy(str[j], temp);
   }
  }
 }

// sorting the words //
printf("\nSorted order.\n");
for(i=0; i<num_words; i++){
	puts(str[i]);
 }
printf("\n");
}

// creating method to find occurances of a string //
void search_occ(char *word, char *all_str){
	int v = 0, m = 0, times = 0, len;
	len = strlen(word);
	while(all_str[v] != '\0'){
		if(all_str[v] == word[m]){
			while(all_str[v] == word[m] && all_str[v] != '\0'){
				v++;
				m++;
   }
			if(m == len && (all_str[n] == ' ' || all_str[v] == '\0')){
				times++;
   }
  }
		else{
			while(all_str[v] != ' '){
				v++;
				if(all_str[v] == '\0')
				break;
   }
  }
		v++;
		m=0;
 }
	if(times > 0){
		printf("%s appears %d times.\n", word, times);
 }
	else{
		printf("'%s' doesn't appear in the sentence.\n", word);
 }
}

// Main method //
int main(int argc, char *argv[]){
	int opt;
	char buff[n], search_str[101];
	FILE *file;
	size_t nread;
	int i, numWords;
printf("Student Name: Rodolfo Garino.\n");
printf("Student ID: 6227112.\n");
	// Opening the file //
	file = fopen(argv[5], "r");
if(file){
	printf("File Content.\n");
	while((nread = fread(buff, 1, sizeof buff, file)) > 0)
		fwrite(buff, 1, nread, stdout);
	if(ferror(file)){
		printf("Error!");
  }
	fclose(file);
 }
// Reading parameters //
while((opt = getopt(argc, argv, ":-f:cs")) != -1){
	switch(opt){
		// Calling method to count number of words //
		case 'c':
			numWords = countWords(buff);
			printf("Number of words = %d\n", numWords);
			break;
		// Calling method for occurances of words //
		case 'f':
			printf("Substring: %s\n", optarg);
			search_occ(optarg, buff);
			break;
		// Calling method for sorting number of words //
		case 's':
			all_words(buff, numWords);
			break;
		// Error options //
		case ':':
			printf("Option needs a value.\n");
			break;
		case '?':
			printf("Unknown option: %c\n", optopt);
			break;
  }
 }
return 0;
}
