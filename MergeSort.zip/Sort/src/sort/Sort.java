/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sort;

import java.util.Arrays;

/**
 *
 * @author Rodolfo
 */

public class Sort {
    
    void merge(int array[], int x, int y, int z){
        int n0 = y - x + 1;
        int n1 = z - y;
        
        // Merging two sub arrays F0 and F1 into array //
        int F0[] = new int[n0];
        int F1[] = new int[n1];
        
        // Setting the values for left and right arrays //
        for(int i = 0; i < n0; i++){
            F0[i] = array [x + i];
            for(int j = 0; j < n1; j++){
                F1[j] = array[y + 1 + j];
            }
        }
        
        // Keeping the values of the current index of sub-arrays and the main array //
        int i = 0;
        int j = 0;
        int k = x;
        
        // If you want to sort the array in descending order switch F0[i] >= F1[j] //
        while(i < n0 && j < n1){
            if(F0[i] <= F1[j]){
                array[k] = F0[i];
                i++;
            }
            else{
                array[k] = F1[j];
                j++;
            }
            k++;
        }
        
        while(i < n0){
            array[k] = F0[i];
            i++;
            k++;
        }
        
        while(j < n1){
            array[k] = F1[j];
            j++;
            k++;
        }
    }
    
    // divide the array into two sub arrays, sort them and merge them //
    void merge_sort(int array[], int left_index, int right_index){
        if(right_index > left_index){
            int mid = (left_index + right_index)/2;
            merge_sort(array, left_index, mid);
            merge_sort(array, mid + 1, right_index);
            merge(array, left_index, mid, right_index);
        }
    }
    
    public static void main(String[] args) {
        
        // creating the unsorted array //
        int[] array = {50, 80, 70, 15, 20, 10, 90, 65, 45};
        
        System.out.println("Unsorted array: " + Arrays.toString(array));
        
        Sort st = new Sort();
        
        // calling the merge_sort method and passing arguments array, first and last index //
        st.merge_sort(array, 0, array.length - 1);
        
        System.out.println("Sorted array: " + Arrays.toString(array));
    }
    
}
