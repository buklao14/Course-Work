class WordMeaningNode

{
    WordMeaning word;
    WordMeaningNode next;

    WordMeaningNode(WordMeaning w)
    {
        word = w;
        next = null;
    }
}
