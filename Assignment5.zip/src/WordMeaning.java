
class WordMeaning
{
    String word;
    String meaning;

    WordMeaning(String w, String m)
    {
        this.word = w;
        this.meaning = m;
    }

    public String getWord()
    {
        return word;
    }

    public String getMeaning()
    {
        return meaning;
    }

}
