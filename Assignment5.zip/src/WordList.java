public class WordList

{
    private WordMeaningNode head;

    WordList()
    {
        head=null;
    }

    void add(WordMeaning wm) {
        WordMeaningNode temp = new WordMeaningNode(wm);

        if (head == null)
            head = temp;
        else {
            WordMeaningNode current = head, back = null;
            boolean check = false;

            while (current != null && !check)
                if (temp.word.getWord().compareToIgnoreCase(current.word.getWord()) < 0)
                    check = true;
                else {
                    back = current;
                    current = current.next;
                }

            temp.next = current;

            if (back == null)
                head = temp;
            else
                back.next = temp;
        }
    }
    public String toString()
        {
            String result = "";
            WordMeaningNode current = head;

            while (current != null)
            {
                result += current.word.getWord() + " = " + current.word.getMeaning() + ".\n";
                current = current.next;
            }
            return result;
        }
    }

