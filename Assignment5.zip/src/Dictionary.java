import java.util.Scanner;

{
    public static void main (String [] args)
    {
        WordList WordL = new WordList();
        Scanner scn = new Scanner(System.in);
        boolean check = false;
        while (!check)

        {
            System.out.println("\n1. Enter a word. \n2. View Dictionary. \n3. Exit. \n");
            int pick = scn.nextInt();
            scn.nextLine();
            switch (pick)
            {
                case 1:
                    System.out.println("Enter a word.");
                    String wordEntry = scn.nextLine();
                    System.out.println("Enter the meaning.");
                    String meaningEntry = scn.nextLine();
                    WordL.add(new WordMeaning(wordEntry, meaningEntry));
                    break;
                case 2:
                    System.out.println();
                    System.out.println(WordL.toString());
                    break;
                case 3:
                    check = true;
                    break;
            }

        }
    }
}
