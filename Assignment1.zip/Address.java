public class Address
{
	private String state;


	public Address(String st)
	{
		state = st;
	}

	public String getState()
	{
		return state;
	}

}