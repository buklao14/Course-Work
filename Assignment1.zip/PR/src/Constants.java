/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rodolfo
 */
public class Constants {
    public final static char LEFT_NORMAL = '(';
    public final static char RIGHT_NORMAL = ')';
    public final static char LEFT_CURLY = '{';
    public final static char RIGHT_CURLY = '}';
    public final static char LEFT_SQUARE = '[';
    public final static char RIGHT_SQUARE = ']';
    public final static char PLUS = '+';
    public final static char MINUS = '-';
    public final static char MULTIPLY = '*';
    public final static char DIVIDE = '/';
    public final static char MODULE = '%';
    public final static char SPACE = ' ';
}
