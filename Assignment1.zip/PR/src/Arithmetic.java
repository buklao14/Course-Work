/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rodolfo
 */
import java.util.EmptyStackException;
import java.util.Scanner;
import java.util.Stack;

   class Arithmetic {
       Stack<Object> st;
       int length;
       String expression;
       String postfix;
       int result;
       
       Arithmetic(String s){
           expression = s;
           length = expression.length();
           st = new Stack<Object>();
           postfix = "";
       }
       
       boolean isBalance(){
           int index = 0;
           boolean fail = false;
           try{
               while(index < length && !fail){
                   char ch = expression.charAt(index);
                   switch(ch){
                       case Constants.LEFT_NORMAL:
                       case Constants.LEFT_CURLY:
                       case Constants.LEFT_SQUARE:
                       st.push(new Character(ch));
                       break;
                       
                       case Constants.RIGHT_NORMAL:
                       char rightBrace = (char) st.pop();
                       if(rightBrace != Constants.LEFT_NORMAL){
                           fail = true;
                       }
                       break;
                       
                       case Constants.RIGHT_CURLY:
                       char rightCurly = (char) st.pop();
                       if(rightCurly != Constants.LEFT_CURLY){
                           fail = true;
                       }
                       break;
                       
                       case Constants.RIGHT_SQUARE:
                       char rightSquare = (char) st.pop();
                       if(rightSquare != Constants.LEFT_SQUARE){
                           fail = true;
                       }
                       break;
                       
                       default:
                           break;
                   }
                   index++;
               }
           }
           catch(EmptyStackException e){
               fail = true;
           }
           return st.empty() && !fail;
       }
       
    void postfixExpression(){
        Scanner sc = new Scanner(expression);
        char current;
        boolean fail = false;
        
        while(sc.hasNext() && !fail){
            String token = sc.next();
            if(isNumber(token)){
                postfix = postfix + token + " ";
            }
            else{
                current = token.charAt(0);
                if(isParentheses(current)){
                    if(st.empty()||current == Constants.LEFT_NORMAL){
                        st.push(new Character(current));
                    }
                    else if(current == Constants.RIGHT_NORMAL){
                        try{
                            char top = (char) st.pop();
                            while(top != Constants.LEFT_NORMAL){
                                postfix = postfix + top + " ";
                                top = (Character) st.pop();
                            }
                        }
                        catch(EmptyStackException e){
                            fail = true;
                        }
                    }
                    else if(st.empty() || current == Constants.LEFT_CURLY){
                        st.push(new Character(current));
                    }
                    else if(current == Constants.RIGHT_CURLY){
                        try{
                            char top = (char) st.pop();
                            while(top != Constants.LEFT_CURLY){
                                postfix = postfix + top + " ";
                                top = (Character) st.pop();
                            }
                        }
                        catch(EmptyStackException e){
                            fail = true;
                        }
                    }
                    else if(st.empty() || current == Constants.LEFT_SQUARE){
                        st.push(new Character(current));
                    }
                    else if(current == Constants.RIGHT_SQUARE){
                        try{
                            char top = (char) st.pop();
                            while(top != Constants.LEFT_SQUARE){
                                postfix = postfix + top + " ";
                                top = (Character) st.pop();
                            }
                        }
                        catch(EmptyStackException e){
                            fail = true;
                        }
                    }
                }
                else if(isOperator(current)){
                    if(st.empty()){
                        st.push(new Character(current));
                    }
                    else{
                        try{
                            char top = (Character)st.peek();
                            boolean higher = hasHigherPrecedence(top, current);
                            while(top != Constants.LEFT_NORMAL && top != Constants.LEFT_SQUARE
                                   && top != Constants.LEFT_CURLY && higher){
                                postfix = postfix + st.pop() + " ";
                                top = (Character)st.peek();
                            }
                            st.push(new Character(current));
                        }
                        catch(EmptyStackException e){
                            st.push(new Character(current));
                        }
                    }
                }
            }
        }
        try{
            while(!st.empty()){
                postfix = postfix + st.pop() + Constants.SPACE;
            }
        }
        catch(EmptyStackException e){
            e.printStackTrace();
        }
    }
    
    public void evaluateRPN(){
        Scanner sc = new Scanner(postfix);
        boolean fail = false;
        while(sc.hasNext() && !fail){
            String token = sc.next();
            try{
                if(isNumber(token)){
                    st.push(token);
                }
                else{
                    int b = Integer.parseInt((String)st.pop());
                    int a = Integer.parseInt((String)st.pop());
                    if(token.equals("+")){
                        st.push((a+b)+"");
                    }
                    else if(token.equals("-")){
                        st.push(a-b + "");
                    }
                    else if(token.equals("*")){
                        st.push(a*b + "");
                    }
                    else if(token.equals("/")){
                        st.push(a/b + "");
                    }
                    else if(token.equals("%")){
                        st.push(a%b + "");
                    }
                }
            }
            catch(EmptyStackException e){
                e.printStackTrace();
                fail = true;
            }
        }
        try{
            if(!st.empty()){
                result = Integer.parseInt((String)st.pop());
            }
        }
        catch(EmptyStackException e){
            e.printStackTrace();
        }
    }
    boolean isNumber(String s){
        try{
            Double.parseDouble(s);
            return true;
        }
        catch(NumberFormatException e){
            return false;
        }
    }
    
    boolean isParentheses(char current){
        switch(current){
            case Constants.RIGHT_NORMAL:
            case Constants.LEFT_NORMAL:
            case Constants.LEFT_SQUARE:
            case Constants.RIGHT_SQUARE:
            case Constants.RIGHT_CURLY:
            case Constants.LEFT_CURLY:
                return true;
            default:
                return false;
        }
    }
    
    boolean isOperator(char ch){
        switch(ch){
            case Constants.PLUS:
            case Constants.MINUS:
            case Constants.MULTIPLY:
            case Constants.DIVIDE:
            case Constants.MODULE:
                return true;
            default:
                return false;
        }
    }
    
    boolean hasHigherPrecedence(char top, char current){
        int topPre = -1;
        int curPre = -1;
        
        if(top == Constants.PLUS || top == Constants.MINUS){
            topPre = 0;
        }
        if(top == Constants.MULTIPLY || top == Constants.DIVIDE || top == Constants.MODULE){
            topPre = 1;
        }
        if(current == Constants.PLUS || current == Constants.MINUS){
            curPre = 0;
        }
        if(current == Constants.MULTIPLY || current == Constants.DIVIDE || current == Constants.MODULE){
            curPre = 1;
        }
        if(topPre > curPre){
            return true;
        }
        else{
            return false;
        }
    }
    String getPostfix(){
        return postfix;
    }
    int getResult(){
        return result;
    }
}
