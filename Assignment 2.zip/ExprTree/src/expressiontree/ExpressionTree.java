/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package expressiontree;
import java.util.*;
/*
 *
 * @author Rodolfo
 */

public class ExpressionTree {
private class NODE {
        private char contents;
        private NODE left;       
        private NODE right;      

        private boolean isLeaf() {
            return (left == null && right == null);
        }
    }
    
    private NODE root;
    private Scanner sc;
    
    public ExpressionTree() {
        root = null;
        sc = new Scanner(System.in);
    }
    
    /*
     * prints the expression tree.
     */
    public void InOrderPrint() {
        if (root != null) {
            InOrderPrintTree(root);
        }
    }
    
    /*
     * Prints the sub trees with their specfic roots.
     */
    private static void InOrderPrintTree(NODE root) {
        if (root.isLeaf())
            System.out.print(root.contents);
        else {
            // internal node - an operator
            System.out.print("(");
            InOrderPrintTree(root.left);
            System.out.print(" " + root.contents + " ");
            InOrderPrintTree(root.right);
            System.out.print(")");
        }
    }
    
    /*
     * Uses prefix notation to print tree
     */
    public void PreOrderPrint() {
        if (root != null) {
            PreOrderPrintTree(root);
        }
    }
    
    /*
     * uses prefix notation to print the expression tree .
     */
    private static void PreOrderPrintTree(NODE root) {
        if (root.isLeaf()) {
            System.out.print(root.contents);
        } else {
            switch (root.contents) {
                case '+':
                    System.out.print("add"); 
                    break;
                case '-':
                    System.out.print("sub"); 
                    break;
                case '*':
                    System.out.print("mult"); 
                    break;
                case '/':
                    System.out.print("divide"); 
                    break;
                case '%':
                    System.out.print("module");
                    break;
            }
             
            System.out.print("( ");
            PreOrderPrintTree(root.left);
            System.out.print(" , ");
            PreOrderPrintTree(root.right);
            System.out.print(" )");
        }
    }
    
    public void PostOrderPrint() {
        if (root != null) {
            PostOrderPrintTree(root, 0);
        }
    }
    
    /*
     * uses postfix notation to print the expression tree.
     */
    private static void PostOrderPrintTree(NODE root, int margin) {
        if (root.isLeaf()) {
            PrintMargin(margin);
            System.out.print(root.contents + "  ");
        } else {
            PostOrderPrintTree(root.left, margin + 1);
            PostOrderPrintTree(root.right, margin + 1);
            
            PrintMargin(margin);
            switch (root.contents) {
                case '+':
                    System.out.print("Add above"); 
                    break;
                case '-':
                    System.out.print("Subtract above"); 
                    break;
                case '*':
                    System.out.print("Multiply above"); 
                    break;
                case '/':
                    System.out.print("Divide above"); 
                    break;
                case '%':
                    System.out.print("Module above");
                    break;
            }
        }
    }
    
    /*
     * printMargin - used to print spaces when outputting
     */
    private static void PrintMargin(int margin) {
        System.out.println();
        for (int i = 1; i <= margin; i++) {
            System.out.print("    ");
        }
    }
    
    /*
     * uses the arithmetic expression obtained from keyboard input 
     * and builds the expression tree
     */
    public void Read() {
        root = ReadTree();
    }
    
    /*
     * uses the arithmetic expression obtained from keyboard 
     * and builds a binary tree
     */
    private NODE ReadTree() {
        NODE n = new NODE();
        
        // Keeps on reading as long as there is no white spcae.
        char ch = sc.findInLine("(\\S)").charAt(0);
        if ((ch >= 'a') && (ch <='z')) {
            n.contents = ch;
            n.left = null;
            n.right = null;
        } else if (ch == '(') {
            n.left = ReadTree();
            n.contents = sc.findInLine("(\\S)").charAt(0);
            n.right = ReadTree();
            ch = sc.findInLine("(\\S)").charAt(0);
            if (ch != ')') {
                System.out.print("EXPECTED ) - } ASSUMED...");
            }
        } else {
            System.out.print("EXPECTED ( - CAN'T PARSE");
            System.exit(1);
        }
        
        return n;
    }

    public static void main(String[] args) {
        // Read in the expression and build the tree.
        System.out.println("\nType a fully parenthesized expression " +
                           "using a..z,+,-,*,/, %");
        
        ExpressionTree tree = new ExpressionTree();
        tree.Read();

        System.out.println("\nInfix Notation:");
        tree.InOrderPrint();
        System.out.print("\n\nPrefix Notation:\n");
        tree.PreOrderPrint();
        System.out.print("\n\nPostfix Notation(tree):");
        tree.PostOrderPrint();
        System.out.println();
    }
}
