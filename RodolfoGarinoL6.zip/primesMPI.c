/*
* Name: Rodolfo Garino W
* Panther ID: 6227112
*
* I affirm that I wrote this program myself without any help from any other people or sources from the internet
* 
*/

#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define LIMIT 50000

int isPrime(int n){
  int i;
	if(n <= 1){
		return 0;
	}
	for(i = 2; i <= n / 2; i++){
		if(n % i == 0){
			return 0;
		}
	}		
  return 1;
}

int main(int argc, char *argv[]){

	//  tasks: number of tasks in partition | identifier: task identifier | start: location of the beggining of calculation | nthsum: calculate every nth number //
	int tasks, identifier, n, primeC, primeSum, found, maxPrime, start, nthsum;

	double start_time, end_time;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &identifier);
	MPI_Comm_size(MPI_COMM_WORLD, &tasks);

	start_time = MPI_Wtime();
	start = (identifier*2) + 1;
	nthsum = tasks * 2;
	primeC = 0;
	found = 0;

	if(identifier == 0){
		for( n = start; n <= LIMIT; n = n + nthsum){
			if(isPrime(n)){
				primeC++;
				found = n;
				printf("ID:%d found Prime#: %d \n",identifier, found);
			}
		}

		MPI_Reduce(&primeC, &primeSum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&found, &maxPrime, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
		
		end_time = MPI_Wtime();

		printf("Largest prime is %d / Total Primes: %d \n", maxPrime, primeSum);
		printf("Time elapsed: %8.6f seconds\n", end_time - start_time);
	}

	if(identifier > 0){
		for(n=start; n <= LIMIT; n = n + nthsum){
			if(isPrime(n)){
				primeC++;
				found = n;
				printf("ID: %d found Prime#: %d \n", identifier, found);
			}
		}

		MPI_Reduce(&primeC, &primeSum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&found, &maxPrime, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);
	}	
	MPI_Finalize();	
}
