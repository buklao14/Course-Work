

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdint.h>

#define NUM_THREADS 10

int sharedNum = 0;

void *thread_manipulation(void *vargp){
    int i = 0;
    int thread_ID = (intptr_t)vargp;

    for(i = 0; i < 6; i++){
        sharedNum = sharedNum + thread_ID;
    }

    printf("Thread [%d] has finished.\n", thread_ID);
}



int main(){

    int i = 0;
    pthread_t tid;

    for (i = 0; i < NUM_THREADS; i++){
        pthread_create(&tid, NULL, thread_manipulation, (void *)(intptr_t) i);
    }

    pthread_join(tid, NULL);

    printf("Value of the shared number after all threads ran: %d\n", sharedNum);

    pthread_exit(NULL);
    return 0;
}
