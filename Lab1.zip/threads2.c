#include <stdio.h>
#include <pthread.h>
#include <math.h>
#include <stdlib.h>

/*Rodolfo Garino W*/

#define NUM_THREADS 4

int SharedVariable = 0;
pthread_mutex_t lock;
pthread_barrier_t bar;

void* threadFunction(void *arg){
	int thread_ID = *((int*)arg);
	int i;

	for(i = 0; i < 20; i++){
		#ifdef PTHREAD_SYNC
		pthread_mutex_lock(&lock);
		#endif

		printf("Thread %d has value %d\n", thread_ID, SharedVariable);
		SharedVariable++;

		#ifdef PTHREAD_SYNC
		pthread_mutex_unlock(&lock);
		#endif
	}

	pthread_barrier_wait(&bar);
	printf("Thread %d has final value %d\n", thread_ID, SharedVariable);
	return NULL;
}

int main(){
	int i;
	int error;

	pthread_t threads[NUM_THREADS];
	int thread_ID[NUM_THREADS] = {0};

	pthread_mutex_init(&lock, NULL);
	pthread_barrier_init(&bar, NULL, NUM_THREADS);

	for(i = 0; i < NUM_THREADS; i++){
		thread_ID[i] = i;
		error = pthread_create(&threads[i], NULL, threadFunction, (void*)&thread_ID[i]);

		if(error){
			printf("Couldn't create thread!");
			exit(-1);
		}
	}

	for(i = 0; i < NUM_THREADS; i++){
		pthread_join(threads[i], NULL);
	}
	return 0;
}
