#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/*Rodolfo Garino W.*/

int SharedVariable = 0;

void *SimpleThread(void *i){
	int *p;
	p = i;

	int num;
	int val = 0;

	for(num = 0; num < 20; num++){
		if(random() > RAND_MAX / 2){
			usleep(10);
		}
		val = SharedVariable;
		printf("thread %d has value %d\n", *p, val);
		SharedVariable = val + 1;
	}

	val = SharedVariable;
	printf("thread %d has final value %d\n", *p, val);
}

int main(int argc, char *argv[]){
	pthread_t *tid;
	int i;

	if(argc != 2){
		printf("invalid number!\n");
		return 0;
	}
	else{
		int valid = 1;
		for(i = 0; i < strlen(argv[1]); i++){
			if(argv[1][i] < '0' || argv[1][i] > '9'){
				valid = 0;
				break;
			}	
		}
		if(valid == 0){
			printf("number can't be a negative number!\n");
		}
		else{
			int x = atoi(argv[1]);
			tid = (pthread_t *)malloc(sizeof(pthread_t)*atoi(argv[1]));
			int *y = (int *)malloc(sizeof(int)*x);

			for(i = 0; i < x; i++){
				y[i] = i;
			}

			for(i = 0; i < x; i++){
				pthread_create(&tid[i], NULL, SimpleThread, &y[i]);
			}

			for(i = 0; i < x; i++){
				pthread_join(tid[i], NULL);
			}
		}
	}
	exit(0);
}
