Rodolfo Garino W.

This is the README file that will show the process required to run the program.
This zip file contains two different programs threads.c and threads2.c, the first one is done without
using synchronization and the second one with sinchronization, the zip file has a Makefile provided 
for simple compilation and creation of both programs executable as well as a clean function to erase both
executable files.

~~~~ NAME OF THE EXECUTABLES AND FILES TO COMPILE ~~~~
first program without sync:
threads.c (to compile)
thread (executable)

second program with sync:
threads2.c (to compile)
thread2 (executable)

------ PROCESS FOR RUNNING THE PROGRAM AND COMPILING ------
1) type 'make' in the command line to compile and create an executable of both files.

2) type the name of the program you wish to run by typing ./"name of the file" "amount of threads to use"
(keep in mind there must a space between the name of the file and the thread desired.)

3) see the output and type 'make clean' to erase both executables of the two files.

4) you could also type clear to clean the command line writing so you have a cleaner screen to look at each
result.
