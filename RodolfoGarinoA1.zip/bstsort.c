//  I Affirm that i wrote this program myself without any help from any other people or source from the internet. //

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <stdbool.h>
#include <string.h>

typedef struct NODE{
	char* key;
	int value;
	struct NODE* left;
	struct NODE* right;
}NODE;

void EnterLine(char* line){
	char* ptr = &(line[0]);
	while(ptr != NULL){
		if((*ptr) == '\n'){
			*ptr = '\0';
			break;
  }
	ptr++;
 }
}

int strcmpSensitive(char* str1, char* str2){
	char* ptr1 = str1;
	char* ptr2 = str2;
	while(ptr1 != '\0' && ptr2 != '\0'){
		if((*ptr1)>(*ptr2)){
			return 1;
		}
		else if((*ptr1)<(*ptr2)){
			return -1;
		}
	ptr1++;
	ptr2++;
 }
	if(ptr1 == '\0' && ptr2 == '\0'){
		return 0;
 }
	else if(ptr1 == '\0'){
		return -1;
 }
	else{
 		return 1;
 }
}

int strcmpInsensitive(char* str1, char* str2){
	char* ptr1 = str1;
	char* ptr2 = str2;
	while(ptr1 != '\0' && ptr2 != '\0'){
		char ch1 = *ptr1;
		char ch2 = *ptr2;
		ch1 = tolower(ch1);
		ch2 = tolower(ch2);
	if(ch1 > ch2){
		return 1;
	}
	else if(ch1 < ch2){
		return -1;
	}
	ptr1++;
	ptr2++;
 }
	if(ptr1 == '\0' && ptr2 == '\0'){
		return 0;
 }
	else if(ptr1 == '\0'){
 		return -1;
 }
	else{
 		return 1;
 }
}

int StringComparison(char* str1, char*str2, bool Sensitive){
	if(Sensitive == true){
		return strcmpSensitive(str1, str2);
 }
	else{
 		return strcmpInsensitive(str1, str2);
 }
}

void Insert(char* tmp, NODE* root, bool Sensitive){
	NODE* temp = root;
	NODE* parent = NULL;
	while(temp != NULL){
		if(StringComparison(temp->key, tmp, Sensitive)==0){
			temp->value = temp->value + 1;
			return;
  }
		else if(StringComparison(temp->key, tmp, Sensitive)>0){
			parent = temp;
			temp = temp->left;
  }
		else{
			parent = temp;
			temp = temp->right;
  }
 }

	NODE* newest = (NODE*)malloc(sizeof(NODE)*1);
	newest->left = NULL;
	newest->right = NULL;
	newest->key = tmp;
	newest->value = 1;

	if(StringComparison(parent->key, tmp, Sensitive)>0){
		parent->left = newest;
 }
	else{
		parent->right = newest;
 }
}

void InOrder(NODE* root){
	if(root == NULL){
	return;
 }
	InOrder(root->left);
	int i;
	for(i=1; i <= root->value; i++){
		printf("%s\n", root->key);
 }
	InOrder(root->right);
}

int main(int argc, char** argv){

bool Sensitive = false;
char* output = "";
char* input = "";
int c;

while((c = getopt(argc, argv, "co:"))!= -1){
	switch(c){
		case 'c':
		Sensitive = true;
		break;

		case 'o':
		output = optarg;
		break;
  }
 }

int size = 100000;
char** arr = (char**)(malloc(sizeof(char*)*size));

int index;
for(index = optind; index < argc; index++){
	input = argv[index];
 }

int ind = 0;
if(strcmp(input,"")==0){
	size_t line_size;
	printf("Enter your String Line By Line.\n");
	char* line = (char*)malloc(sizeof(char)*101);
	while(getline(&line, &line_size, stdin)!= 1){
		if(strcmp(line,"\n")==0)
			break;
		EnterLine(line);
		arr[ind++] = line;
		line = (char*)malloc(sizeof(char)*101);
  }
 }
else{
	FILE *file = fopen(input, "r");
	char* line = (char*)malloc(sizeof(char)*101);
	size_t line_size;

	while(getline(&line, &line_size, file)!= -1){
		EnterLine(line);
		arr[ind++] = line;
		line = (char*)malloc(sizeof(char)*101);
  }
 }

int j;
int SizeTree = 0;
NODE* root;

for(j=0; j<ind; j++){
	char* tmp = arr[j];
	if(SizeTree == 0){
		NODE* newest = (NODE*)malloc(sizeof(NODE)*1);
		newest->key = tmp;
		newest->value = 1;
		newest->left = NULL;
		newest->right = NULL;
		root = newest;
  }
	else{
		Insert(tmp, root, Sensitive);
  }
	SizeTree++;
 }
InOrder(root);
return 0;
}
