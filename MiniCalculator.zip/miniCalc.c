// I Affirm that i wrote this program myself without any help from any other people or source from the internet. //

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
printf("Student Name: Rodolfo Garino.\n");
printf("Panther ID: 6227112.\n");
// initializing operations //
int option;
int add;
int sub;
int mul;
int div;
int value;

// creating the flags for the operations //
int addFlag = 0;
int subFlag = 0;
int mulFlag = 0;
int divFlag = 0;
int sqrFlag = 0;

// using getopt function for red flagging //
while((option = getopt(argc, argv,"a:d:m:s:x"))!= -1){
	switch(option){
	 // finding flags in each command line argument //
	 case 'a':
	 add = atoi(optarg); // atoi changes strings to integers //
	 if(add > 500 || add < 1){
	  printf("For the A option values should be only between 1 and 50.\n");
	 }
	 else{
	  addFlag = 1;
	 }
	 break;

	 case 'd':
	 div = atoi(optarg);
	 if(div > 5 || div < 1){
	  printf("For the D option values should be only between 1 and 5.\n");
	 }
	 else{
	  divFlag = 1;
	 }
	 break;

	 case'm':
	 mul = atoi(optarg);
	 if(mul > 5 || mul < 1){
	  printf("For the M option values should be only between 1 and 5.\n");
	 }
	 else{
	  mulFlag = 1;
	 }
	 break;

	 case 's':
	 sub = atoi(optarg);
	 if(sub > 500 || sub < 1){
	  printf("For the S option values should be only between 1 and 500.\n");
	 }
	 else{
	  subFlag = 1;
	 }
	 break;

	 case 'x':
	 sqrFlag = 1;
	 break;

	 case ':':
	 printf("options need values.\n");
	 break;

	 case '?':
	 printf("unknown option.\n");
	 break;
  }
 }
	// if no value is provided display error message //
	if(argv[optind] == NULL){
	 printf("Value has not been provided.\n");
	 return -1;
	}

	// storing the operands for values //
	value = atoi(argv[optind]);

	// checking parameters of operands //
	if(value > 50 || value < 1){
	 printf("Value should be between 1 and 50.\n");
	 return -1;
	}

	// creating if statements for each flag, if flag is set, do corresponding operation //
	if(sqrFlag){
	 value = value * value;
	 printf("After squaring value becomes: %d\n", value);
	}
	
	if(divFlag){
	 value = value / div;
	 printf("After dividing value becomes: %d\n", value);
	}

	if(mulFlag){
	 value = value * mul;
	 printf("After multiplying value becomes: %d\n", value);
	}

	if(addFlag){
	 value = value + add;
	 printf("After Adding value becomes: %d\n", value);
	}
	
	if(subFlag){
	 value = value - sub;
	 printf("After Substracting value becomes: %d\n", value);
	}
	// printing final result of all operations //
	printf("Final result is: %d\n", value);
	return 0;
}
